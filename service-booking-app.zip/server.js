const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const db = new sqlite3.Database('./users.db');

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'src')));

// Create tables if not exist
db.run(`CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mobileNumber TEXT UNIQUE,
    name TEXT,
    role TEXT DEFAULT 'customer'
)`);
db.run(`CREATE TABLE IF NOT EXISTS providers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    latitude REAL,
    longitude REAL,    
    name TEXT,
    mobileNumber TEXT UNIQUE,
    gender TEXT,
    age INTEGER,
    skills TEXT,
    location TEXT,
    taluk TEXT,
    district TEXT,
    state TEXT,
    role TEXT DEFAULT 'provider'
)`);
db.run(`CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customerMobile TEXT,
    providerMobile TEXT,
    status TEXT DEFAULT 'pending',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
)`);
db.run(`CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bookingId INTEGER,
    customerMobile TEXT,
    providerMobile TEXT,
    rating INTEGER,
    comment TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
)`);

// Register customer
app.post('/api/register/customer', (req, res) => {
    const { mobileNumber, name } = req.body;
    db.run(
        `INSERT INTO customers (mobileNumber, name) VALUES (?, ?)`,
        [mobileNumber, name],
        function(err) {
            if (err) return res.status(400).json({ error: err.message });
            res.json({ id: this.lastID, mobileNumber, name });
        }
    );
});

// Register provider
app.post('/api/register/provider', (req, res) => {
    const { mobileNumber, name, skills, location, taluk, district, state } = req.body;
    db.run(
        `INSERT INTO providers (mobileNumber, name, skills, location, taluk, district, state) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [mobileNumber, name, skills, location, taluk, district, state],
        function(err) {
            if (err) return res.status(400).json({ error: err.message });
            res.json({ id: this.lastID, mobileNumber, name, skills, location, taluk, district, state });
        }
    );
});

// Login
app.post('/api/login', (req, res) => {
    const { mobileNumber, userType } = req.body;
    const table = userType === 'provider' ? 'providers' : 'customers';
    db.get(
        `SELECT * FROM ${table} WHERE mobileNumber = ?`,
        [mobileNumber],
        (err, row) => {
            if (err) return res.status(500).json({ error: err.message });
            if (row) return res.json({ success: true, user: row });
            res.status(401).json({ success: false, message: 'Invalid credentials' });
        }
    );
});

// Search providers with filters
app.get('/api/providers', (req, res) => {
    let sql = `SELECT p.*, 
        (SELECT AVG(rating) FROM reviews WHERE providerMobile = p.mobileNumber) as avgRating
        FROM providers p WHERE 1=1`;
    const params = [];

    if (req.query.skill) {
        sql += ` AND LOWER(p.skills) LIKE ?`;
        params.push(`%${req.query.skill.toLowerCase()}%`);
    }
    if (req.query.location) {
        sql += ` AND LOWER(p.location) LIKE ?`;
        params.push(`%${req.query.location.toLowerCase()}%`);
    }
    if (req.query.taluk) {
        sql += ` AND LOWER(p.taluk) LIKE ?`;
        params.push(`%${req.query.taluk.toLowerCase()}%`);
    }
    if (req.query.district) {
        sql += ` AND LOWER(p.district) LIKE ?`;
        params.push(`%${req.query.district.toLowerCase()}%`);
    }
    if (req.query.state) {
        sql += ` AND LOWER(p.state) LIKE ?`;
        params.push(`%${req.query.state.toLowerCase()}%`);
    }
    if (req.query.minRating) {
        sql += ` AND (avgRating IS NULL OR avgRating >= ?)`;
        params.push(Number(req.query.minRating));
    }

    sql += ` ORDER BY avgRating DESC NULLS LAST`;

    db.all(sql, params, (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// Create a booking
app.post('/api/bookings', (req, res) => {
    const { customerMobile, providerMobile } = req.body;
    db.run(
        `INSERT INTO bookings (customerMobile, providerMobile, status) VALUES (?, ?, 'pending')`,
        [customerMobile, providerMobile],
        function(err) {
            if (err) return res.status(400).json({ error: err.message });
            res.json({ id: this.lastID, customerMobile, providerMobile, status: 'pending' });
        }
    );
});

// Get bookings for a customer or provider
app.get('/api/bookings', (req, res) => {
    const { customer, provider } = req.query;
    let sql = '';
    let param = '';
    if (customer) {
        sql = `SELECT * FROM bookings WHERE customerMobile = ? ORDER BY createdAt DESC`;
        param = customer;
    } else if (provider) {
        sql = `SELECT * FROM bookings WHERE providerMobile = ? ORDER BY createdAt DESC`;
        param = provider;
    } else {
        return res.status(400).json({ error: 'Missing customer or provider parameter' });
    }
    db.all(sql, [param], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// Provider responds to a booking
app.post('/api/bookings/:id/respond', (req, res) => {
    const { status } = req.body;
    db.run(
        `UPDATE bookings SET status = ? WHERE id = ?`,
        [status, req.params.id],
        function(err) {
            if (err) return res.status(400).json({ error: err.message });
            res.json({ success: true });
        }
    );
});

// Submit a review
app.post('/api/reviews', (req, res) => {
    const { bookingId, customerMobile, providerMobile, rating, comment } = req.body;
    db.run(
        `INSERT INTO reviews (bookingId, customerMobile, providerMobile, rating, comment) VALUES (?, ?, ?, ?, ?)`,
        [bookingId, customerMobile, providerMobile, rating, comment],
        function(err) {
            if (err) return res.status(400).json({ error: err.message });
            res.json({ id: this.lastID, bookingId, customerMobile, providerMobile, rating, comment });
        }
    );
});

// Get reviews for provider or customer
app.get('/api/reviews', (req, res) => {
    const { provider, customerMobile } = req.query;
    if (provider) {
        db.all(
            `SELECT * FROM reviews WHERE providerMobile = ? ORDER BY createdAt DESC`,
            [provider],
            (err, rows) => {
                if (err) return res.status(500).json({ error: err.message });
                res.json(rows);
            }
        );
    } else if (customerMobile) {
        db.all(
            `SELECT * FROM reviews WHERE customerMobile = ? ORDER BY createdAt DESC`,
            [customerMobile],
            (err, rows) => {
                if (err) return res.status(500).json({ error: err.message });
                res.json(rows);
            }
        );
    } else {
        return res.status(400).json({ error: 'Missing provider or customerMobile parameter' });
    }
});

// Get average rating for provider
app.get('/api/providers/:mobile/average-rating', (req, res) => {
    db.get(
        `SELECT AVG(rating) as avgRating FROM reviews WHERE providerMobile = ?`,
        [req.params.mobile],
        (err, row) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ avgRating: row.avgRating });
        }
    );
});

// Get unique skills
app.get('/api/skills', (req, res) => {
    db.all(
        `SELECT skills FROM providers WHERE skills IS NOT NULL AND skills != ''`,
        [],
        (err, rows) => {
            if (err) return res.status(500).json({ error: 'DB error' });
            let allSkills = [];
            rows.forEach(r => {
                if (r.skills) {
                    r.skills.split(',').forEach(s => {
                        const skill = s.trim();
                        if (skill) allSkills.push(skill);
                    });
                }
            });
            allSkills = [...new Set(allSkills)].sort((a, b) => a.localeCompare(b));
            res.json(allSkills);
        }
    );
});

// Unique districts and taluks with filtering
app.get('/api/districts', (req, res) => {
    const { state } = req.query;
    const sql = state
        ? `SELECT DISTINCT district FROM providers WHERE LOWER(state) = ? AND district IS NOT NULL AND district != '' ORDER BY district COLLATE NOCASE ASC`
        : `SELECT DISTINCT district FROM providers WHERE district IS NOT NULL AND district != '' ORDER BY district COLLATE NOCASE ASC`;
    const params = state ? [state.toLowerCase()] : [];
    db.all(sql, params, (err, rows) => {
        if (err) return res.status(500).json({ error: 'DB error' });
        res.json(rows.map(r => r.district));
    });
});

app.get('/api/taluks', (req, res) => {
    const { district } = req.query;
    const sql = district
        ? `SELECT DISTINCT taluk FROM providers WHERE LOWER(district) = ? AND taluk IS NOT NULL AND taluk != '' ORDER BY taluk COLLATE NOCASE ASC`
        : `SELECT DISTINCT taluk FROM providers WHERE taluk IS NOT NULL AND taluk != '' ORDER BY taluk COLLATE NOCASE ASC`;
    const params = district ? [district.toLowerCase()] : [];
    db.all(sql, params, (err, rows) => {
        if (err) return res.status(500).json({ error: 'DB error' });
        res.json(rows.map(r => r.taluk));
    });
});

app.get('/api/locations', (req, res) => {
    const { state, district, taluk } = req.query;
    let sql = `SELECT DISTINCT location FROM providers WHERE location IS NOT NULL AND location != ''`;
    const params = [];

    if (state) {
        sql += ` AND LOWER(state) = ?`;
        params.push(state.toLowerCase());
    }
    if (district) {
        sql += ` AND LOWER(district) = ?`;
        params.push(district.toLowerCase());
    }
    if (taluk) {
        sql += ` AND LOWER(taluk) = ?`;
        params.push(taluk.toLowerCase());
    }

    sql += ` ORDER BY location COLLATE NOCASE ASC`;

    db.all(sql, params, (err, rows) => {
        if (err) return res.status(500).json({ error: 'DB error' });
        res.json(rows.map(r => r.location));
    });
});

// Get all unique states
app.get('/api/states', (req, res) => {
    db.all(
        `SELECT DISTINCT state FROM providers WHERE state IS NOT NULL AND state != '' ORDER BY state COLLATE NOCASE ASC`,
        [],
        (err, rows) => {
            if (err) return res.status(500).json({ error: 'DB error' });
            res.json(rows.map(r => r.state));
        }
    );
});

// Get customer by mobile number
app.get('/api/customers/:mobile', (req, res) => {
    db.get(
        `SELECT * FROM customers WHERE mobileNumber = ?`,
        [req.params.mobile],
        (err, row) => {
            if (err) return res.status(500).json({ error: err.message });
            if (row) return res.json(row);
            res.status(404).json({ error: 'Customer not found' });
        }
    );
});

// Get provider by mobile number
app.get('/api/providers/:mobile', (req, res) => {
    db.get(
        `SELECT * FROM providers WHERE mobileNumber = ?`,
        [req.params.mobile],
        (err, row) => {
            if (err) return res.status(500).json({ error: err.message });
            if (row) return res.json(row);
            res.status(404).json({ error: 'Provider not found' });
        }
    );
});

// ----------------------
const PORT = 3001;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
